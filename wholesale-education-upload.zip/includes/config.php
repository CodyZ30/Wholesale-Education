<?php
// Global site configuration

// Enable error display site-wide (remove in production if desired)
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

define('SITE_NAME', 'Gotta.Fish');

?>
